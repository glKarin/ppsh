#include "mainwindow.h"

MainWindow::MainWindow(QObject *rootObject)
{
}


MainWindow::~MainWindow()
{
}
